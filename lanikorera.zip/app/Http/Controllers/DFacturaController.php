<?php

namespace App\Http\Controllers;

use App\DFactura;
use Illuminate\Http\Request;

class DFacturaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DFactura  $dFactura
     * @return \Illuminate\Http\Response
     */
    public function show(DFactura $dFactura)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DFactura  $dFactura
     * @return \Illuminate\Http\Response
     */
    public function edit(DFactura $dFactura)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DFactura  $dFactura
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DFactura $dFactura)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DFactura  $dFactura
     * @return \Illuminate\Http\Response
     */
    public function destroy(DFactura $dFactura)
    {
        //
    }
}
