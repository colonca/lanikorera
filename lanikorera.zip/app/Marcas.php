<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Marcas extends Model
{
    Protected $fillable = ['id','nombre'];
}
