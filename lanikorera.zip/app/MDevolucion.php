<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MDevolucion extends Model
{
    //
}
