<?php return array (
  'facturas.factura' => 'App\\Http\\Livewire\\Facturas\\Factura',
);