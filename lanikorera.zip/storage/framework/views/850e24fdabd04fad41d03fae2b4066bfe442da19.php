
<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb " style="margin-bottom: 30px;background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white" href="<?php echo e(route('admin.ventas')); ?>">Ventas</a></li>
        <li class="active"><a style="color: white"href="<?php echo e(route('deuda.index')); ?>">Deudas</a></li>
        <li class="active"><a style="color: white" >Facturas en Deuda</a></li>
        <li class="active"><a style="color: white" >Abonar</a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
           <div class="col-md-6">
               <div class="card">
                   <div class="header">
                       <h2>
                           DEUDA- ACTUALIZAR.
                       </h2>
                   </div>
                   <div class="body">
                       <div class="table-responsive">
                           <form class="" method="POST" action="<?php echo e(route('deuda.update', $factura->id)); ?>">
                               <?php echo csrf_field(); ?>
                               <input name="_method" type="hidden" value="PUT" />
                               <div class="col-md-12">

                                       <div class="form-group">
                                           <div class="form-line" >
                                               <label for="exampleFormControlSelect1">Id factura</label>
                                               <br/><input type="text" class="form-control"  placeholder="Id factura" value="<?php echo e($factura->serie.'-'.$factura->n_venta); ?>" name="idFactura" required="required" disabled />
                                           </div>
                                           <div class="form-line">
                                               <label for="exampleFormControlSelect1">Nombres</label>
                                               <br/><input type="text" class="form-control" placeholder="Nombres del cliente"  value="<?php echo e($factura->nombres); ?>" name="nombres"required="required" disabled/>
                                           </div>
                                           <div class="form-line">
                                               <label for="exampleFormControlSelect1">Apellidos</label>
                                               <br/><input type="text" class="form-control" placeholder="apellidos del cliente"  value="<?php echo e($factura->apellidos); ?>"name="apellidos" required="required" disabled/>
                                           </div>
                                           <div class="form-line">
                                               <label for="exampleFormControlSelect1">Total</label>
                                               <br/><input type="number" class="form-control" placeholder="Total de l factura"  value="<?php echo e($factura->total); ?>"name="total" required="required" disabled/>
                                           </div>
                                           <div class="form-line">
                                               <label for="exampleFormControlSelect1">Medio de Pago</label>
                                               <br/>
                                               <select name="medio_pago" id="" class="form-control">
                                                   <option value="efectivo">Efectivo</option>
                                                   <option value="datafono">Datafono</option>
                                                   <option value="transferencia">Transferencia</option>
                                               </select>
                                           </div>
                                           <div class="form-line">
                                               <label for="exampleFormControlSelect1">Valor</label>
                                               <br/><input type="number" class="form-control" placeholder="0.00"  name="valor" required="required" />
                                           </div>
                                       </div>

                                   <div class="form-group">
                                       <button class="btn bg-green waves-effect" type="submit">Actualizar</button>
                                   </div>
                               </div>
                           </form>
                       </div>
                   </div>
               </div>
           </div>
        <div class="col-md-6">
            <div class="card">
                <div class="header">
                    <h2>
                        DEUDAS- LISTADO DE ABONOS.
                    </h2>
                </div>
                <div class="body">
                    <div class="table-responsive">
                        <table id="tabla" class="table table-bordered table-striped table-hover table-responsive table-condensed dataTable js-exportable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Abonos</th>
                                <th>Medio de Pago</th>
                                <th>Fecha</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $abonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($abono->abono); ?></td>
                                        <td><?php echo e($abono->medio_pago); ?></td>
                                        <td><?php echo e($abono->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            //$('#tabla').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\ventas\deudas\abonar.blade.php ENDPATH**/ ?>