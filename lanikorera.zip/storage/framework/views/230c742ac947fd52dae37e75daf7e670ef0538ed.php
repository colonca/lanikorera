<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white"href="<?php echo e(route('admin.ventas')); ?>">Ventas</a></li>
        <li class="active"><a style="color:white" href="<?php echo e(route('clientes.index')); ?>">Clientes</a></li>
        <li class="active"><a style="color:white" href="">Editado Cliente <?php echo e($clientes->nombres); ?></a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .form-line {
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    DATOS DE VENTAS - CLIENTES EN EL SISTEMA - EDITANDO CLIENTE.<small>Edite los datos en los campos de su elección y haga click en el boton Actualizar</small>
                </h2>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <h1 class="card-inside-title">DATOS DEL CLIENTE</h1>
                <div class="row clearfix">
                    <div class="col-md-12">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('clientes.update', $clientes->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="_method" type="hidden" value="PUT" />
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="form-line" >
                                        <label for="exampleFormControlSelect1">Identidicación</label>
                                        <br/><input type="number" class="form-control" placeholder="Escriba la cedula del cliente" value="<?php echo e($clientes->identificacion); ?>" name="identificacion" required="required" />
                                    </div>
                                    <div class="form-line">
                                        <label for="exampleFormControlSelect1">Nombres</label>
                                        <br/><input type="text" class="form-control" placeholder="Escriba nombre del cliente" value="<?php echo e($clientes->nombres); ?>" name="nombres"required="required"/>
                                    </div>
                                    <div class="form-line">
                                        <label for="exampleFormControlSelect1">Apellidos</label>
                                        <br/><input type="text" class="form-control" placeholder="Escriba apellidos del cliente" value="<?php echo e($clientes->apellidos); ?>" name="apellidos" required="required"/>
                                    </div>
                                    <div class="form-line">
                                        <label for="exampleFormControlSelect1">Telefono</label>
                                        <br/><input type="number" class="form-control" placeholder="Escriba telefono del cliente" value="<?php echo e($clientes->telefono); ?>" name="telefono" required="required"/>
                                    </div>
                                    <div class="form-line">
                                        <label for="exampleFormControlSelect1">Email</label>
                                        <br/><input type="email" class="form-control" placeholder="email@example.com" value="<?php echo e($clientes->email); ?>" name="email" required="required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <br/><br/><a href="<?php echo e(route('clientes.index')); ?>" class="btn bg-red waves-effect">Cancelar</a>
                                    <button class="btn bg-indigo waves-effect" type="reset">Limpiar Formulario</button>
                                    <button class="btn bg-green waves-effect" type="submit">Actualizar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views/ventas/clientes/edit.blade.php ENDPATH**/ ?>