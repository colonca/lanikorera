
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
    <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
    <li><a style="color:white" href="<?php echo e(route('admin.reportes')); ?>">Reportes</a></li>
    <li class="active"><a style="color:white" >Stock</a></li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    REPORTES - STOCK
                </h2>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table id="tabla" class="table table-bordered table-striped table-hover table-responsive table-condensed dataTable js-exportable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Stock Mínimo</th>
                                <th>Stock Actual</th>
                                <th>Costo Unitario Promedio</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $inventario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->producto); ?>

                                <td><?php echo e($item->stock_minimo); ?>

                                <td><?php echo e($item->stock); ?>

                                <td>$ <?php echo e(number_format($item->costo_promedio)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        //$('#tabla').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\reportes\stock\stock.blade.php ENDPATH**/ ?>