
<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb" style="margin-bottom: 30px;background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white" href="<?php echo e(route('admin.ventas')); ?>">Ventas</a></li>
        <li class="active"><a style="color:white" href="<?php echo e(route('descuentos.index')); ?>">Descuentos</a></li>
        <li class="active"><a style="color:white" href="">Creando nuevo Descuento</a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .form-line {
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    DATOS DE VENTAS - DESCUENTOS EN EL SISTEMA. <small>Ingrese los datos y haga click en el boton Guardar.</small>
                </h2>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <div class="row clearfix">
                    <div class="col-md-12" style="margin-bottom: 0;">
                        <form id="form" action="<?php echo e(route('descuentos.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-6" style="margin-bottom: 0">
                                    <div class="form-group">
                                            <label for="">Fecha Inicio</label>
                                            <input type="date" id="datePicker" name="fecha_inicio" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required="required">
                                    </div>
                                </div>
                                <div class="col-md-6" style="margin-bottom: 0">
                                    <div class="form-group">
                                        <label for="">Fecha Final</label>
                                        <input type="date" id="datePicker" name="fecha_fin" class="form-control" value="<?php echo e(date('Y-m-d')); ?>"required="required">
                                    </div>
                                </div>
                            </div>

                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-4" style="display: flex">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="">Codigo de Barras</label>
                                            <input type="hidden" name="producto_embalaje_id" id="producto_embalaje">
                                            <input type="text" class="form-control" id="codigo" onkeypress="buscarProducto(event)" placeholder="scanee o ingrese el codigo del producto" required="required">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="">Cantidad Destinda</label>
                                            <br/><input id="cantidad" type="number" class="form-control" placeholder="Cantidad de la promoción" name="cantidad_destinada" required="required"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="">Precio</label>
                                            <br/><input type="text" id="costo_promedio" class="form-control" min="1" placeholder="precio de la promoción" name="valor" required="required"/>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <br/><br/><a href="<?php echo e(route('descuentos.index')); ?>" class="btn bg-red waves-effect">Cancelar</a>
                                <button class="btn bg-indigo waves-effect" type="reset">Limpiar Formulario</button>
                                <button class="btn bg-green waves-effect" type="submit">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function buscarProducto(event){
            if(event.keyCode == 13){
                event.preventDefault();
                const  codigo = $('#codigo').val();
                $.ajax({
                    type: 'GET',
                    url: '<?php echo e(url('almacen/producto/search')); ?>/'+codigo,
                }).done(function (msg) {
                    if(msg.status == 'ok'){
                        $('#producto_embalaje').val(msg.producto.unicode);
                        document.getElementById('costo_promedio').value = msg.producto.costo_promedio;
                        $('#cantidad').focus();
                    }else{
                        notify('Atención', 'El producto con el codigo ' + $('#cogigo').val() +' no ha sido registrado.!', 'warning');
                        $('#cogigo').val('');
                    }
                });
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views/ventas/descuentos/create.blade.php ENDPATH**/ ?>