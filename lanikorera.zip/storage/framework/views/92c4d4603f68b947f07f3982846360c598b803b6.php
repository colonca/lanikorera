<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount($name, $params)->dom;
} elseif ($_instance->childHasBeenRendered('OaKEHT5')) {
    $componentId = $_instance->getRenderedChildComponentId('OaKEHT5');
    $componentTag = $_instance->getRenderedChildComponentTagName('OaKEHT5');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OaKEHT5');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $dom = $response->dom;
    $_instance->logRenderedChild('OaKEHT5', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
<?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\vendor\livewire\livewire\src\views\mount-component.blade.php ENDPATH**/ ?>