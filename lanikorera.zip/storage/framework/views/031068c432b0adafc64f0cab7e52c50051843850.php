<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white" href="<?php echo e(route('admin.almacen')); ?>">Almacen</a></li>
        <li class="active"><a style="color:white" href="<?php echo e(route('subcategorias.index')); ?>">Subcategorías</a></li>
        <li class="active"><a style="color:white" href="">Creando nueva Subcategoría</a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .form-line {
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    DATOS DEL ALMACEN - SUBCATEGORÍAS EN EL SISTEMA.<small>Ingrese los datos y haga click en el boton Guardar.</small>
                </h2>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <h1 class="card-inside-title">DATOS DE LA SUBCATEGORÍA</h1>
                <div class="row clearfix">
                    <div class="col-md-12">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('subcategorias.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label for="">Categoria</label>
                                        <select name="categoria_id" id="categorias_id" class="form-control">
                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-line">
                                        <label for="exampleFormControlSelect1">Nombre</label>
                                        <br/><input type="text" class="form-control" placeholder="Escriba el nombre de la subcategoria" name="nombre" required="required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <br/><br/><a href="<?php echo e(route('subcategorias.index')); ?>" class="btn bg-red waves-effect">Cancelar</a>
                                    <button class="btn bg-indigo waves-effect" type="reset">Limpiar Formulario</button>
                                    <button class="btn bg-green waves-effect" type="submit">Guardar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views/almacen/subcategorias/create.blade.php ENDPATH**/ ?>