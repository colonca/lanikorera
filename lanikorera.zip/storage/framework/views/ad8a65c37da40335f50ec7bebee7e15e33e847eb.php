<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Ingresar | <?php echo e(config('app.name')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('img/logomi.png')); ?>">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plugins/node-waves/waves.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/plugins/animate-css/animate.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head                        >
<body class="login-page">
<div class="login-box">
    <div class="logo">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" width="350">
    </div>
</div>
<?php echo $__env->yieldContent('content'); ?>
<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('js/node-waves/waves.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-validation/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/examples/sign-in.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\layouts\app.blade.php ENDPATH**/ ?>