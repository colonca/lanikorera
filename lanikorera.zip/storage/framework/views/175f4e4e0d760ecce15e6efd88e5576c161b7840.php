<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li class="active"><a style="color:white" href="#">Cambiar Contraseña</a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h2>
                        CAMBIAR CONTRASEÑA
                    </h2>
                    <ul class="header-dropdown m-r--5">
                        <li class="dropdown">
                            <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <i class="material-icons">more_vert</i>
                            </a>
                            <ul class="dropdown-menu pull-right">
                                <li><a data-toggle="modal" data-target="#mdModal">Ayuda</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="body">
                    <div class="col-md-12">
                        <?php $__env->startComponent('layouts.errors'); ?>
                        <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('usuario.cambiarcontrasenia')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label>Escriba Su Contraseña Actual</label>
                                            <br/><input type="password" class="form-control"
                                                        name="pass0" required="required"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label>Escriba la Nueva Contraseña</label>
                                            <br/><input type="password" name="pass1" placeholder="Mínimo 6 caracteres"
                                                        class="form-control" required="required"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label>Vuelva a Escribir La Nueva Contraseña</label>
                                            <br/><input type="password" name="pass2" placeholder="Mínimo 6 caracteres"
                                                        class="form-control" required="required"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <br/><br/><a href="<?php echo e(route('inicio')); ?>" class="btn bg-red waves-effect">Cancelar</a>
                                        <button class="btn bg-indigo waves-effect" type="reset">Limpiar Formulario</button>
                                        <button class="btn bg-green waves-effect" type="submit">Guardar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="mdModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="defaultModalLabel">SOBRE LOS PROGRAMAS DE APOYO</h4>
                </div>
                <div class="modal-body">
                    Cambie la contraseña para el inicio de sesión.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">ACEPTAR</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\pass.blade.php ENDPATH**/ ?>