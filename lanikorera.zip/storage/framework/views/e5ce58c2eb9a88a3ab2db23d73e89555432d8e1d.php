
<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white" href="<?php echo e(route('admin.reportes')); ?>">Reportes</a></li>
        <li class="active"><a style="color:white" > Reporte_Ventas</a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h2>
                        REPORTES - VENTAS <small>Seleccione las fechas a consultar y visualice las ventas totales, Número de ventas, Ganacias, margen de utilidad promedio, las ventas en dinero en efectivo, datafono, deudas y lo abonos realizados.</small>
                    </h2>
                </div>
                <div class="body">
                    <div class="col-md-12">
                        <?php $__env->startComponent('layouts.errors'); ?>
                        <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="row clearfix">
                        <form class="form-horizontal" style="width: 90%; margin: 0 auto;" method="GET" action="<?php echo e(route('reporte.ventas')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="exampleFormControlSelect1">Fecha Inicial</label>
                                            <input type="date" name="fecha_inicial"  class="form-control" placeholder="Desde"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="exampleFormControlSelect1">Fecha Final</label>
                                            <input type="date" name="fecha_final"  class="form-control" placeholder="Hasta"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <button type="submit" class="btn waves-effect btn-block" style="background-color: #38383A; color:white;">CONSULTAR</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-pink hover-expand-effect">
                <div class="icon">
                    <i class="fas fa-cash-register"></i>
                </div>
                <div class="content">
                    <div class="text">Ventas Totales</div>
                    <div class="number count-to" data-from="0" data-to="125" data-speed="15" data-fresh-interval="20">
                        <?php echo e(number_format($reporte['total_vendido'],2)); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-cyan hover-expand-effect">
                <div class="icon">
                    <i class="fas fa-sort-numeric-up-alt"></i>
                </div>
                <div class="content">
                    <div class="text">Numero de Ventas</div>
                    <div class="number count-to" data-from="0" data-to="257" data-speed="1000" data-fresh-interval="20"><?php echo e($reporte['numero_ventas']); ?></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-light-green hover-expand-effect">
                <div class="icon">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="content">
                    <div class="text">Ganancia</div>
                    <div class="number count-to" data-from="0" data-to="243" data-speed="1000" data-fresh-interval="20">
                        <?php echo e(number_format($reporte['ganancia'],2)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-orange hover-expand-effect">
                <div class="icon">
                    <i class="fas fa-percent"></i>
                </div>
                <div class="content">
                    <div class="text">Margen de Ganancia</div>
                    <div class="number count-to" data-from="0" data-to="1225" data-speed="1000" data-fresh-interval="20">
                        <?php echo e($reporte['margen_ganancia'].'%'); ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <!-- Task Info -->
        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="card">
                <div class="header">
                    <h2>VENTAS POR FORMA DE PAGO</h2>
                </div>
                <div class="body">
                    <div class="table-responsive">
                        <table class="table table-hover dashboard-task-infos">
                            <tbody>
                                <?php $__currentLoopData = $reporte['medios_pago']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                         <td><?php echo e(strtoupper($medio->medio_pago)); ?></td>
                                         <td>$ <?php echo e(number_format($medio->total,2)); ?></td>
                                     </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Task Info -->
        <!-- Browser Usage -->
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <div class="card">
                <div class="header">
                    <h2>ABONOS POR FORMA DE PAGO</h2>
                </div>
                <div class="body">
                    <div class="table-responsive">
                        <table class="table table-hover dashboard-task-infos">
                            <tbody>
                            <?php $__currentLoopData = $reporte['abonos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(strtoupper($abono->medio_pago)); ?></td>
                                    <td>$ <?php echo e(number_format($abono->total,2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Browser Usage -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            //$('#tabla').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views/reportes/ventas/index.blade.php ENDPATH**/ ?>