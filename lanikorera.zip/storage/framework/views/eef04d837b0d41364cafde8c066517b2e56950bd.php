<!DOCTYPE html>
<html lang="en">
<head>
    <title>La Nikorera</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/icons/favicon.ico')); ?>"/>
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/animate/animate.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/css-hamburgers/hamburgers.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/animsition/css/animsition.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/select2/select2.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/daterangepicker/daterangepicker.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
    <!--===============================================================================================-->

    <style>
        .logo {
            object-fit: cover;
            width: 70%;
        }
    </style>

</head>
<body>

<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100">
            <div class="login100-form-title" style="background-image:url(<?php echo e(asset('images/user-img-background.jpg')); ?>);">
                <img src="" alt="">
                <span class="login100-form-title-1">
						<img class="logo" src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                </span>
            </div>
            <?php if(session()->has('flag')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('flag')); ?>

                </div>
            <?php endif; ?>
            <form class="login100-form validate-form" action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="wrap-input100 validate-input m-b-26 <?php echo e($errors->has('identificacion') ? 'has-error' : ''); ?>" data-validate="Usuario requerido">
                    <input class="input100" type="text" name="identificacion" value="<?php echo e(old('identificacion')); ?>" placeholder="Ingresa tu Identificación">
                    <span class="focus-input100"></span>
                </div>

                <div class="wrap-input100 validate-input m-b-18"  data-validate = "Clave requerida">
                    <input class="input100" type="password" name="password" placeholder="Digite la clave">
                    <span class="focus-input100"></span>
                </div>

                <div class="<?php echo e($errors->has('identificacion') ? 'alert alert-danger' : ''); ?>">
                    <?php echo $errors->first('identificacion','<span class="help-block">:message</span>'); ?>

                </div>
                <div class="<?php echo e($errors->has('password') ? 'alert alert-danger' : ''); ?>">
                    <?php echo $errors->first('password','<span class="help-block">:message</span>'); ?>

                </div>
                <div class="container-login100-form-btn">
                    <button class="login100-form-btn" type="submit">
                        Iniciar Sesión
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!--===============================================================================================-->
<script src="<?php echo e(asset('vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<!--===============================================================================================-->
<script src="<?php echo e(asset('vendor/animsition/js/animsition.min.js')); ?>"></script>
<!--===============================================================================================-->
<script src="<?php echo e(asset('vendor/bootstrap/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--===============================================================================================-->
<script src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>"></script>
<!--===============================================================================================-->
<script src="<?php echo e(asset('vendor/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/daterangepicker/daterangepicker.js')); ?>"></script>
<!--===============================================================================================-->
<script src="<?php echo e(asset('vendor/countdowntime/countdowntime.js')); ?>"></script>
<!--===============================================================================================-->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\auth\login.blade.php ENDPATH**/ ?>