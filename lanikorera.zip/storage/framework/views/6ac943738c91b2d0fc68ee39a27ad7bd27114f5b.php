<div>
    <div class="row clearfix" style="position: relative;">
        <div wire:loading>
            <div id="loader"></div>
            <div id="myDiv"></div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h2>
                        DATOS DE VENTAS - FACTURA DE VENTA. <small>Ingrese los datos, scanee el codigo de barras y haga click en el boton Guardar.</small>
                    </h2>
                </div>
                <div class="body">
                    <div class="col-md-12">
                        <?php $__env->startComponent('layouts.errors'); ?>
                        <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12" style="margin-bottom: 0;">
                            <form id="form" wire:submit.prevent="guardar" method="POST" >
                                <?php echo csrf_field(); ?>
                                <div class="row" style="width: 90%; margin: 0 auto;">
                                    <div class="col-md-3" style="margin-bottom: 0">
                                        <div class="form-group">
                                            <label for="">Fecha</label>
                                            <input type="date" disabled id="datePicker" name="fecha" class="form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6" style="margin-bottom: 0">
                                        <div class="form-group">
                                            <label for="">Cliente</label>
                                            <div class="proveedor" style="display: flex; width: 100%">
                                                <input type="hidden" wire:model="cliente_id">
                                                <input type="text" disabled class="form-control" id="c_identificacion" placeholder="ingrese la identificacion o nombre del cliente">
                                                <button class="btn btn-success btn-circle" onclick="event.preventDefault()" data-toggle="modal" data-target="#Mcreate" style="margin-right: 5px;"><i class="fas fa-plus"></i></button>
                                                <button class="btn btn-info btn-circle" onclick="clientes(event)"><i class="fas fa-search"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3" style="margin-bottom: 0">
                                        <div class="form-group">
                                            <label for="">Nombre</label>
                                            <input type="text"  disabled id="c_nombres" class="form-control" placeholder="JUANITO PROVEEDOR">
                                        </div>
                                    </div>
                                </div>
                                <div class="row" style="width: 90%; margin: 0 auto;">
                                    <div class="col-md-3" style="margin-bottom: 0">
                                        <div class="form-group">
                                            <label for="">Bodegas</label>
                                            <select wire:model="bodega" class="form-control">
                                                <?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($bodega->id); ?>"><?php echo e($bodega->nombre); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3" style="margin-bottom: 0">
                                        <div class="form-group">
                                            <label for="">Modalidad de Pago</label>
                                            <select wire:model="modalidad_pago" class="form-control" id="">
                                                <option value="contado" selected>CONTADO</option>
                                                <option value="credito">CREDITO</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3" style="margin-bottom: 0">
                                        <div class="form-group">
                                            <label for="">Medio de pago</label>
                                            <select wire:model="medio_pago" wire:click="change()" class="form-control" >
                                                <option value="efectivo" selected>EFECTIVO</option>
                                                <option value="datafono">DATAFONO</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3" style="margin-bottom: 0">
                                        <div class="form-group">
                                            <label for="">Factura de Venta</label>
                                            <input type="text" disabled class="form-control" wire:model="venta">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-12">
                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-6">
                                    <form wire:submit.prevent="searchProduct"  style="display: flex">
                                        <input type="text" wire:model.lazy="search"  class="form-control" placeholder="scanee o ingrese el codigo del producto">
                                        <button type="submit" class="btn btn-info">Enter para agregar</button>
                                    </form>
                                </div>
                                <div class="col-md-6" style="display: flex; justify-content: flex-end;">
                                    <button class="btn btn-warning btn-circle" data-toggle="modal" data-target="#MAdicional"><i class="fab fa-amilia"></i></button>
                                </div>
                            </div>
                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-12">
                                    <table class="table table-bordered">
                                        <thead class="bg-info" >
                                        <th>Codigo</th>
                                        <th>Producto</th>
                                        <th>Embalaje</th>
                                        <th>Cantidad</th>
                                        <th>Precio</th>
                                        <th>Total</th>
                                        </thead>
                                        <tbody id="productos">
                                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($producto['codigo_de_barras']); ?></td>
                                                <td><?php echo e($producto['nombre'].'x'.$producto['presentacion']); ?></td>
                                                <td><?php echo e($producto['embalaje']); ?></td>
                                                <td><input type="number" id="<?php echo e($producto['unicode']); ?>" wire:click="addCantidad('<?php echo e($producto['unicode']); ?>',$event.target.value)" wire:keydown.debounce.500ms="addCantidad('<?php echo e($producto['unicode']); ?>',$event.target.value)" style="border-radius: 20px; border:1px solid grey; width: 60px; padding: 5px;" value="<?php echo e($producto['cantidad']); ?>"></td>
                                                <td><?php echo e($producto['precio_show']); ?></td>
                                                <td><?php echo e($producto['total']); ?></td>
                                                <td style="text-align: center;">
                                                    <a href="" wire:click.prevent="delete('<?php echo e($producto['unicode']); ?>')"
                                                       class="btn btn-danger waves-effect btn-xs" data-toggle="tooltip"
                                                       data-placement="top" title="Eliminar" style="padding: 5px;"><i class="far fa-trash-alt"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $adicionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adicional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($adicional['unicode']); ?></td>
                                                <td><?php echo e($adicional['nombre']); ?></td>
                                                <td>UNIDAD</td>
                                                <td><input type="number" id="<?php echo e($adicional['unicode']); ?>" wire:click="addCantidadAdicional('<?php echo e($adicional['unicode']); ?>',$event.target.value)"  wire:kerdown="addCantidadAdicional('<?php echo e($adicional['unicode']); ?>',$event.target.value)"  style="border-radius: 20px; border:1px solid grey; width: 60px; padding: 5px;" value="<?php echo e($adicional['cantidad']); ?>"></td>
                                                <td><?php echo e(number_format($adicional['precio'])); ?></td>
                                                <td><?php echo e($adicional['total']); ?></td>
                                                <td style="text-align: center;">
                                                    <a href="" wire:click.prevent="deleteAdicional('<?php echo e($adicional['unicode']); ?>')"
                                                       class="btn btn-danger waves-effect btn-xs" data-toggle="tooltip"
                                                       data-placement="top" title="Eliminar" style="padding: 5px;"><i class="far fa-trash-alt"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-12" style="display: flex; justify-content: flex-end; margin-bottom: 0;">
                                    <p><strong>Total:</strong> </p>
                                    <p id="f_total">$ <?php echo e(number_format($total)); ?></p>
                                </div>
                            </div>
                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-12" style="display: flex; justify-content: flex-end;">
                                    <a href="<?php echo e(route('admin.compras')); ?>" class="btn btn-danger" style="margin-right: 5px;">Cancelar</a>
                                    <button class="btn btn-success" wire:click="guardar">Facturar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\livewire\facturas\factura.blade.php ENDPATH**/ ?>