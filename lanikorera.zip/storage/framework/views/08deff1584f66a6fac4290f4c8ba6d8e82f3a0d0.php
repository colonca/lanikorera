<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
    <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
    <li><a style="color:white" href="<?php echo e(route('admin.usuarios')); ?>">Usuarios</a></li>
    <li><a style="color:white" href="<?php echo e(route('grupousuario.index')); ?>">Grupos de Usuarios</a></li>
    <li class="active"><a style="color:white" >Ver Grupo</a></li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    USUARIOS DEL SISTEMA - GRUPOS DE USUARIOS O ROLES
                </h2>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <h1 class="card-inside-title">DATOS DEL GRUPO SELECCIONADO</h1>
                <div class="row clearfix">
                    <div class="col-md-12">
                        <table class="table table-hover">
                            <tbody>
                                <tr class="read">
                                    <td class="contact"><b>Id del Grupo</b></td>
                                    <td class="subject"><?php echo e($grupo->id); ?></td>
                                </tr>
                                <tr class="read">
                                    <td class="contact"><b>Nombre</b></td>
                                    <td class="subject"><?php echo e($grupo->nombre); ?></td>
                                </tr>
                                <tr class="read">
                                    <td class="contact"><b>Descripción</b></td>
                                    <td class="subject"><?php echo e($grupo->descripcion); ?></td>
                                </tr>
                                <tr class="read">
                                    <td class="contact"><b>Cantidad de Usuarios en el Grupo</b></td>
                                    <td class="subject"><?php echo e($total); ?></td>
                                </tr>
                                <tr class="read">
                                    <td class="contact"><b>Creado</b></td>
                                    <td class="subject"><?php echo e($grupo->created_at); ?></td>
                                </tr>
                                <tr class="read">
                                    <td class="contact"><b>Modificado</b></td>
                                    <td class="subject"><?php echo e($grupo->updated_at); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="list-group">
                            <a style="background-color: #38383A; color:white;" class="list-group-item ">
                                MÓDULOS A LOS QUE TIENE ACCESO EL GRUPO DE USUARIOS
                            </a>
                            <?php $__currentLoopData = $grupo->modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="list-group-item"><?php echo e($modulo->nombre); ?> ==> <?php echo e($modulo->descripcion); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\usuarios\grupos_usuarios\show.blade.php ENDPATH**/ ?>