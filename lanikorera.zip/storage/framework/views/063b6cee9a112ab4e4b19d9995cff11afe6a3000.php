<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb " style="margin-bottom: 30px;background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white" href="<?php echo e(route('admin.ventas')); ?>">Ventas</a></li>
        <li class="active"><a style="color: white"href="<?php echo e(route('deuda.index')); ?>">Deudas</a></li>
        <li class="active"><a style="color: white" >Facturas en Deuda</a></li>
        <li class="active"><a style="color:white" >Detalles</a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h2>
                        DETALLE DE LA FACTURA.
                    </h2>
                </div>
                <div class="body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="bg-info" >
                            <th>Codigo</th>
                            <th>Producto</th>
                            <th>Embalaje</th>
                            <th>Cantidad</th>
                            <th>Precio</th>
                            <th>Total</th>
                            </thead>
                            <tbody id="productos">
                            <?php $total = 0?>
                            <?php $__currentLoopData = $factura->dfactura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($detalle->producto_embalaje->codigo_de_barras); ?></td>
                                    <td><?php echo e($detalle->producto_embalaje->producto->nombre.'X'.$detalle->producto_embalaje->producto->presentacion); ?></td>
                                    <td><?php echo e($detalle->producto_embalaje->embalaje->descripcion); ?></td>
                                    <td><?php echo e($detalle->cantidad); ?></td>
                                    <td>$ <?php echo e($detalle->precio); ?></td>
                                    <td>$ <?php echo e($detalle->cantidad*$detalle->precio); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $factura->adicionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adicional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($adicional->id); ?></td>
                                    <td><?php echo e($adicional->nombre); ?></td>
                                    <td><?php echo e($adicional->cantidad); ?></td>
                                    <td>UNIDAD</td>
                                    <td>$ <?php echo e($adicional->precio_venta); ?></td>
                                    <td>$ <?php echo e($adicional->cantidad*$adicional->precio_venta); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            //$('#tabla').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\ventas\deudas\detalles.blade.php ENDPATH**/ ?>