<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
    <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
    <li><a style="color:white" href="<?php echo e(route('admin.usuarios')); ?>">Usuarios</a></li>
    <li class="active"><a style="color:white">Editar/Eliminar Usuario</a></li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    USUARIOS DEL SISTEMA - EDITAR/ELIMINAR USUARIO
                </h2>
                <ul class="header-dropdown m-r--5">
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="material-icons">more_vert</i>
                        </a>
                        <ul class="dropdown-menu pull-right">
                            <li><a data-toggle="modal" data-target="#mdModal">Ayuda</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <h1 class="card-inside-title">DATOS DEL USUARIO</h1>
                <div class="row clearfix">
                    <div class="col-md-12">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('usuario.update',$user->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="_method" type="hidden" value="PUT" />
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <br/><input type="text" value="<?php echo e($user->identificacion); ?>" class="form-control" placeholder="Escriba el número de identificación del usuario, con éste tendrá acceso al sistema" name="identificacion" required="required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <br/><input type="text" value="<?php echo e($user->nombres); ?>" class="form-control" placeholder="Escriba los nombres del usuario" name="nombres" id="txt_nombres" required="required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <br/><input type="text" value="<?php echo e($user->apellidos); ?>" class="form-control" placeholder="Escriba los apellidos del usuario" name="apellidos" id="txt_apellidos" required="required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <br/><input type="email" value="<?php echo e($user->email); ?>" class="form-control" placeholder="Escriba el correo electrónico del usuario" name="email" id="txt_email" required="required" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <br/><label>Estado del Usuario</label>
                                        <br/><select class="form-control show-tick select2" name="estado" placeholder="-- Seleccione Estado del Usuario --" required="">
                                            <?php if($user->estado=='ACTIVO'): ?>
                                            <option value="ACTIVO" selected="">ACTIVO</option>
                                            <option value="INACTIVO">INACTIVO</option>
                                            <?php else: ?>
                                            <option value="ACTIVO">ACTIVO</option>
                                            <option value="INACTIVO" selected="">INACTIVO</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Seleccione los Grupos o Roles de Usuarios</label>
                                        <br/><select class="form-control show-tick select2" name="grupos[]" placeholder="Seleccione los Grupos o Roles de Usuarios" required="" multiple="">
                                            <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $existe = false;
                                            ?>
                                            <?php $__currentLoopData = $user->grupousuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($m->id==$key): ?>
                                            <?php
                                            $existe = true;
                                            ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($existe): ?>
                                            <option value="<?php echo e($key); ?>" selected><?php echo e($value); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <br/><br/><a href="<?php echo e(route('admin.usuarios')); ?>" class="btn bg-red waves-effect">Cancelar</a>
                                    <button class="btn bg-indigo waves-effect" type="reset">Limpiar Formulario</button>
                                    <button class="btn bg-green waves-effect" type="submit">Guardar</button>
                                    <a href="<?php echo e(route('usuario.delete',$user->id)); ?>" class="btn bg-red waves-effect">Eliminar Usuario</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    USUARIOS DEL SISTEMA - CAMBIAR CONTRASEÑA
                </h2>
                <ul class="header-dropdown m-r--5">
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="material-icons">more_vert</i>
                        </a>
                        <ul class="dropdown-menu pull-right">
                            <li><a data-toggle="modal" data-target="#mdModal">Ayuda</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <h1 class="card-inside-title">DATOS DEL USUARIO</h1>
                <div class="row clearfix">
                    <div class="col-md-12">
                        <form class="form form-horizontal" role="form" method="POST" action="<?php echo e(route('usuario.cambiarPass')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <div class="form-line">
                                        <br/><input type="text" name="identificacion2" value="<?php echo e($user->identificacion); ?>" class="form-control" readonly="" required="required" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Escriba la Nueva Contraseña</label>
                                        <br/><input type="password" name="pass1" placeholder="Mínimo 6 caracteres" class="form-control" required="required" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Vuelva a Escribir La Nueva Contraseña</label>
                                        <br/><input type="password" name="pass2" placeholder="Mínimo 6 caracteres" class="form-control" required="required" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button class="btn bg-indigo waves-effect" type="reset">Limpiar</button>
                                    <button class="btn bg-green waves-effect" type="submit">Guardar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="mdModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content modal-col-brown">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">SOBRE LOS USUARIOS</h4>
            </div>
            <div class="modal-body">
                <strong>Edite ó elimine un usuario del sistema. Además, puede cambiar la contraseña.</strong>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">ACEPTAR</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('.select2').select2();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\usuarios\usuarios\edit.blade.php ENDPATH**/ ?>