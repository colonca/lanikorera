<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white"href="<?php echo e(route('admin.ventas')); ?>">Ventas</a></li>
        <li class="active"><a style="color:white" href="<?php echo e(route('descuentos.index')); ?>">Descuentos</a></li>
        <li class="active"><a style="color:white" href="">Editado Descuento </a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .form-line {
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    DATOS DE VENTAS - DESCUENTOS EN EL SISTEMA - EDITANDO DESCUENTO.<small>Edite los datos en los campos de su elección y haga click en el boton Actualizar</small>
                </h2>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <div class="row clearfix">
                    <div class="col-md-12" style="margin-bottom: 0;">
                        <form id="form" action="<?php echo e(route('descuentos.update',$descuento->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input name="_method" type="hidden" value="PUT" />
                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-6" style="margin-bottom: 0">
                                    <div class="form-group">
                                        <label for="">Fecha Inicio</label>
                                        <input type="date" id="datePicker" name="fecha" class="form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6" style="margin-bottom: 0">
                                    <div class="form-group">
                                        <label for="">Fecha Final</label>
                                        <input type="date" id="datePicker" name="fecha" class="form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row" style="width: 90%; margin: 0 auto;">
                                <div class="col-md-4" style="display: flex">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="">Codigo de Barras</label>
                                            <input type="hidden" name="producto_embalaje_id" id="producto_embalaje" >
                                            <input type="text" class="form-control" id="cogigo" onkeypress="buscarProducto(event)" placeholder="scanee o ingrese el codigo del producto" value="<?php echo e($descuento->codigo_de_barras); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="">Cantidad Destinda</label>
                                            <br/><input id="cantidad" type="number" class="form-control" placeholder="Cantidad de la promoción" name="cantidad_destinada"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <label for="">Precio</label>
                                            <br/><input type="text" id="costo_promedio" class="form-control" min="1" placeholder="precio de la promoción" name="valor"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <div class="form-group">
                                    <br/><br/><a href="<?php echo e(route('descuentos.index')); ?>" class="btn bg-red waves-effect">Cancelar</a>
                                    <button class="btn bg-indigo waves-effect" type="reset">Limpiar Formulario</button>
                                    <button class="btn bg-green waves-effect" type="submit">Actualizar</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\ventas\descuentos\edit.blade.php ENDPATH**/ ?>