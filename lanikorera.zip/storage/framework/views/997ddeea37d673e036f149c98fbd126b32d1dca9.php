<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb" style="margin-bottom: 30px; background-color: #38383A">
        <li><a style="color:white" href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
        <li><a style="color:white" href="<?php echo e(route('admin.compras')); ?>">Compras</a></li>
        <li class="active"><a style="color:white" href="<?php echo e(route('proveedores.index')); ?>">Proveedores</a></li>
        <li class="active"><a style="color:white" href="">Editado Proveedor <?php echo e($proveedor->nombre); ?></a></li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2>
                    DATOS DE COMPRAS - PROVEEDORES EN EL SISTEMA - EDITANDO PROVEEDOR.<small>Edite los datos en los campos de su elección y haga click en el boton Actualizar</small>
                </h2>
            </div>
            <div class="body">
                <div class="col-md-12">
                    <?php $__env->startComponent('layouts.errors'); ?>
                    <?php if (isset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9)): ?>
<?php $component = $__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9; ?>
<?php unset($__componentOriginal7b52b96780f185f8fdc141ab1066fccc27d485a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
                <h1 class="card-inside-title">DATOS DEL PROVEEDOR</h1>
                <div class="row clearfix">
                    <div class="col-md-12">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('proveedores.update',$proveedor->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="_method" type="hidden" value="PUT" />
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label for="exampleFormControlSelect1">Nit</label>
                                        <br/><input type="text" class="form-control" placeholder="Escriba el nit del proveedor" value="<?php echo e($proveedor->nit); ?>" name="nit" required />
                                    </div>
                                    <div class="form-line">
                                        <label for="exampleFormControlSelect1">Nombre</label>
                                        <br/><input type="text" class="form-control" placeholder="Escriba el nombre del proveedor" value="<?php echo e($proveedor->nombre); ?>" name="nombre" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <br/><br/><a href="<?php echo e(route('proveedores.index')); ?>" class="btn bg-red waves-effect">Cancelar</a>
                                    <button class="btn bg-indigo waves-effect" type="reset">Limpiar Formulario</button>
                                    <button class="btn bg-green waves-effect" type="submit">Actualizar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\compras\proveedores\edit.blade.php ENDPATH**/ ?>