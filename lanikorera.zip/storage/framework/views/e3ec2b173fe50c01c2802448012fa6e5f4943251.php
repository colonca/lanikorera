

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="body">
        <form class="form-horizontal" method="POST" action="<?php echo e(route('rol')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="input-group">
                <div class="form-line">
                    <select class="form-control show-tick" name="grupo" placeholder="-- Seleccione Rol Para Continuar --">
                        <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <button class="btn btn-block bg-pink waves-effect" type="submit">CONTIUAR</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lanikorera\lanikorera\resources\views\auth\rol.blade.php ENDPATH**/ ?>