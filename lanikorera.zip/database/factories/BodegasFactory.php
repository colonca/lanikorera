<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Bodegas;
use Faker\Generator as Faker;

$factory->define(Bodegas::class, function (Faker $faker) {
    return [
        //
    ];
});
