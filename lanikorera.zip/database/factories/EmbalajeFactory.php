<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\embalajes;
use Faker\Generator as Faker;

$factory->define(embalajes::class, function (Faker $faker) {
    return [
        //
    ];
});
