<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DCompra;
use Faker\Generator as Faker;

$factory->define(DCompra::class, function (Faker $faker) {
    return [
        //
    ];
});
