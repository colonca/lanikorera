<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Compra;
use Faker\Generator as Faker;

$factory->define(Compra::class, function (Faker $faker) {
    return [
        //
    ];
});
