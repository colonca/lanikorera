<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Proveedores;
use Faker\Generator as Faker;

$factory->define(Proveedores::class, function (Faker $faker) {
    return [
        //
    ];
});
