<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MDevolucion;
use Faker\Generator as Faker;

$factory->define(MDevolucion::class, function (Faker $faker) {
    return [
        //
    ];
});
