<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MFactura;
use Faker\Generator as Faker;

$factory->define(MFactura::class, function (Faker $faker) {
    return [
        //
    ];
});
