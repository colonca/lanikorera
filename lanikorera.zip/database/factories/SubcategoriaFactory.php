<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Subcategoria;
use Faker\Generator as Faker;

$factory->define(Subcategoria::class, function (Faker $faker) {
    return [
        //
    ];
});
