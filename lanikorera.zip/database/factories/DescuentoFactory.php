<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Descuento;
use Faker\Generator as Faker;

$factory->define(Descuento::class, function (Faker $faker) {
    return [
        //
    ];
});
