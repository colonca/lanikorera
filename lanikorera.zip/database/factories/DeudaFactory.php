<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Deuda;
use Faker\Generator as Faker;

$factory->define(Deuda::class, function (Faker $faker) {
    return [
        //
    ];
});
