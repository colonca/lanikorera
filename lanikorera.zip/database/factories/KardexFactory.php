<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Kardex;
use Faker\Generator as Faker;

$factory->define(Kardex::class, function (Faker $faker) {
    return [
        //
    ];
});
