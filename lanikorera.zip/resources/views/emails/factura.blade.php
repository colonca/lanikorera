<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:wght@100;500&family=Oswald:wght@300&display=swap');
        .container {
            width: 60%;
        }
        h1 {
            color: rgb(79, 75, 75);
            font-family: 'Barlow Semi Condensed', sans-serif;
        }
        p {
            color: rgb(79, 75, 75);
            font-family: 'Barlow Semi Condensed', sans-serif;
        }
    </style>
</head>
<body>
<header>
    <div class="container" style=" width: 60%;">
       <p>Gracias por su compra</p>
    </div>
</header>

<main>

</main>
</body>
</html>

